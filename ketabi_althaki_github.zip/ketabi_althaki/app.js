const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
const config=window.APP_CONFIG||{};
let supabaseClient=null, authMode="email", pendingLogin="", currentGrade=null,currentSubject=null, viewLevel="grades";
const grades=[
 {id:"ninth",name:"الصف التاسع",desc:"المرحلة الأساسية",icon:"🎒",color:"#eaf1ff",accent:"#3768d9"},
 {id:"first",name:"الأول الثانوي",desc:"المرحلة الثانوية",icon:"🎓",color:"#e4f7f0",accent:"#209875"},
 {id:"third",name:"الثالث الثانوي",desc:"القسم العلمي",icon:"🏅",color:"#fff2df",accent:"#bd8525"}
];
const subjects=[
 {name:"الرياضيات",icon:"📐"},{name:"الفيزياء",icon:"⚛️"},{name:"الكيمياء",icon:"🧪"},{name:"الأحياء",icon:"🧬"},{name:"اللغة العربية",icon:"📖"},{name:"اللغة الإنجليزية",icon:"🌐"}
];
const resources=[
 {id:"book",name:"الكتاب المدرسي",desc:"الكتاب والدروس حسب ترتيب المنهج",icon:"📘",color:"blue"},
 {id:"solved",name:"الكتاب المحلول",desc:"حلول وشروحات إضافية — قسم مميز",icon:"✨",color:"gold",tag:"مميز"},
 {id:"models",name:"النماذج الوزارية",desc:"نماذج تدريبية وأسئلة وزارية",icon:"📑",color:"teal"},
 {id:"exam",name:"اختبار وزاري",desc:"اختبر نفسك واحصل على التصحيح",icon:"📝",color:"purple"}
];
function init(){if(config.SUPABASE_URL?.startsWith("http")&&config.SUPABASE_ANON_KEY&&!config.SUPABASE_ANON_KEY.startsWith("YOUR_")){supabaseClient=window.supabase.createClient(config.SUPABASE_URL,config.SUPABASE_ANON_KEY);supabaseClient.auth.getSession().then(({data})=>{if(data.session)showApp(data.session.user);});}}
init();
$$(".tab").forEach(b=>b.addEventListener("click",()=>{ $$(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");authMode=b.dataset.mode;$("#loginValue").value="";$("#loginValue").type=authMode==="email"?"email":"tel";$("#loginValue").placeholder=authMode==="email"?"name@example.com":"+967 7XXXXXXXX";$("#loginValue").autocomplete=authMode==="email"?"email":"tel";$("#loginLabel").textContent=authMode==="email"?"البريد الإلكتروني":"رقم الهاتف";$("#authMessage").textContent="";}));
$("#loginForm").addEventListener("submit",async e=>{e.preventDefault();const value=$("#loginValue").value.trim();if(!value)return;pendingLogin=value;
 if(authMode==="email"){if(!supabaseClient){msg("أضف إعدادات Supabase في config.js لتفعيل رموز البريد.");return;}const {error}=await supabaseClient.auth.signInWithOtp({email:value,options:{shouldCreateUser:true}});if(error){msg(error.message,true);return;}$("#loginForm").classList.add("hidden");$("#verifyForm").classList.remove("hidden");msg("تم طلب رمز الدخول. افحص بريدك الإلكتروني.");}
 else{if(!config.WHATSAPP_OTP_ENDPOINT){msg("خدمة واتساب غير مربوطة بعد. أضف رابط خادم WhatsApp Business API في config.js.",true);return;}try{const r=await fetch(config.WHATSAPP_OTP_ENDPOINT,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({phone:value})});if(!r.ok)throw Error("تعذر إرسال الرمز");$("#loginForm").classList.add("hidden");$("#verifyForm").classList.remove("hidden");msg("تم طلب رمز واتساب.");}catch(err){msg(err.message,true);}}
});
$("#verifyForm").addEventListener("submit",async e=>{e.preventDefault();const token=$("#otpValue").value.trim();if(authMode==="phone"){try{const endpoint=config.WHATSAPP_OTP_ENDPOINT.replace(/\\/send-otp\\/?$/,"/verify-otp");const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({phone:pendingLogin,code:token})});const result=await r.json();if(!r.ok||!result.verified)throw Error(result.message||"رمز التحقق غير صحيح");showApp({phone:pendingLogin});}catch(err){msg(err.message,true);}return;}const {data,error}=await supabaseClient.auth.verifyOtp({email:pendingLogin,token,type:"email"});if(error){msg(error.message,true);return;}showApp(data.user);});
$("#backLogin").onclick=()=>{$("#verifyForm").classList.add("hidden");$("#loginForm").classList.remove("hidden");$("#otpValue").value="";};
function msg(t,bad=false){$("#authMessage").textContent=t;$("#authMessage").style.color=bad?"#bd4c59":"#2d7b5c";}
function showApp(user){$("#authScreen").classList.add("hidden");$("#app").classList.remove("hidden");$("#userEmail").textContent=user?.email||user?.phone||"الطالب";renderGrades();showPage("home");}
$("#logoutBtn").onclick=async()=>{if(supabaseClient)await supabaseClient.auth.signOut();location.reload();};
function showPage(name){["home","library","tests"].forEach(p=>$("#"+p+"Page").classList.toggle("hidden",p!==name));$$(".nav-link[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===name));$("#pageCrumb").textContent={home:"الرئيسية",library:"المكتبة التعليمية",tests:"اختباراتي"}[name];$("#sidebar").classList.remove("open");}
$$(".nav-link[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
$("#browseBtn").onclick=()=>{showPage("library");renderGrades(true);};$("#goLibrary").onclick=()=>{showPage("library");renderGrades(true);};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
function renderGrades(inLibrary=false){$("#gradeGrid").innerHTML=grades.map(g=>`<article class="grade-card" data-grade="${g.id}"><div class="grade-top"><div class="grade-icon" style="background:${g.color}">${g.icon}</div><span class="grade-arrow">←</span></div><h3>${g.name}</h3><p>${g.desc}</p></article>`).join("");$("#gradeGrid").querySelectorAll("[data-grade]").forEach(c=>c.onclick=()=>{showPage("library");openGrade(c.dataset.grade);});if(inLibrary)openLibraryGrades();}
function openLibraryGrades(){viewLevel="grades";$("#libraryTitle").textContent="اختر الصف الدراسي";$("#backBtn").classList.add("hidden");$("#libraryContent").innerHTML=`<div class="subject-grid">${grades.map(g=>`<article class="subject-card" data-grade="${g.id}"><div class="subject-emoji">${g.icon}</div><h3>${g.name}</h3><p>${g.desc}</p></article>`).join("")}</div>`;$("#libraryContent").querySelectorAll("[data-grade]").forEach(c=>c.onclick=()=>openGrade(c.dataset.grade));}
function openGrade(id){currentGrade=grades.find(g=>g.id===id);viewLevel="subjects";$("#libraryTitle").textContent=currentGrade.name+" — المواد العلمية";$("#backBtn").classList.remove("hidden");$("#libraryContent").innerHTML=`<div class="subject-grid">${subjects.map(s=>`<article class="subject-card" data-subject="${s.name}"><div class="subject-emoji">${s.icon}</div><h3>${s.name}</h3><p>الأقسام والموارد التعليمية</p></article>`).join("")}</div>`;$("#libraryContent").querySelectorAll("[data-subject]").forEach(c=>c.onclick=()=>openSubject(c.dataset.subject));}
function openSubject(name){currentSubject=name;viewLevel="resources";$("#libraryTitle").textContent=currentGrade.name+" / "+name;$("#libraryContent").innerHTML=`<div class="resource-grid">${resources.map(r=>`<article class="resource-card" data-resource="${r.id}"><div class="resource-icon ${r.color}">${r.icon}</div><div><h3>${r.name} ${r.tag?'<span class="mini-tag">مميز</span>':''}</h3><p>${r.desc}</p></div><span class="arrow">←</span></article>`).join("")}</div>`;$("#libraryContent").querySelectorAll("[data-resource]").forEach(c=>c.onclick=()=>openResource(c.dataset.resource));}
function openResource(id){const r=resources.find(x=>x.id===id);$("#modalTitle").textContent=r.name;$("#modalText").textContent=`${currentGrade.name} • ${currentSubject} • ${r.name}. أضف ملفات PDF أو الدروس لهذا القسم من لوحة إدارة المحتوى عند تجهيزها.`;$("#modalAction").textContent=id==="exam"?"ابدأ الاختبار قريباً":"حسناً";$("#resourceModal").classList.remove("hidden");}
$("#closeModal").onclick=()=>$("#resourceModal").classList.add("hidden");$("#modalAction").onclick=()=>$("#resourceModal").classList.add("hidden");$("#resourceModal").addEventListener("click",e=>{if(e.target.id==="resourceModal")e.currentTarget.classList.add("hidden");});
$("#backBtn").onclick=()=>{if(viewLevel==="resources")openGrade(currentGrade.id);else openLibraryGrades();};
$("#searchInput").addEventListener("input",e=>{const q=e.target.value.trim();if(viewLevel==="subjects"){$$("#libraryContent .subject-card").forEach(c=>c.style.display=c.textContent.includes(q)?"":"none");}else if(viewLevel==="resources"){$$("#libraryContent .resource-card").forEach(c=>c.style.display=c.textContent.includes(q)?"":"none");}});
$("#gradeGrid").innerHTML="";