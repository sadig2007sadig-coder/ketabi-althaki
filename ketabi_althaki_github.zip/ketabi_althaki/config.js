/*
  إعدادات الربط:
  1) أنشئ مشروعاً مجانياً في https://supabase.com
  2) من Project Settings > API انسخ Project URL و anon/public key.
  3) ضع القيمتين أدناه.
  4) فعّل Email OTP من Authentication > Providers > Email.
  ملاحظة: لا تضع service_role key هنا أبداً.
*/
window.APP_CONFIG = {
  SUPABASE_URL: "YOUR_SUPABASE_PROJECT_URL",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_PUBLIC_KEY",
  // رابط خادمك الذي يرسل رمز واتساب عبر WhatsApp Business API.
  // مثال: https://your-domain.com/api/whatsapp/send-otp
  WHATSAPP_OTP_ENDPOINT: ""
};